#!/system/bin/sh
# Magisk Module: Disable Battery Optimization for TV Apps (Fixed)
# Author: Tony Vu

MODDIR=${0%/*}

# Đợi hệ thống boot xong hoàn toàn
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 2
done
# Đợi thêm cho chắc (UI và app đã load xong)
sleep 20

log_file="$MODDIR/log.txt"
echo "=== Starting disable battery optimization ===" > $log_file
date >> $log_file

disable_optimization() {
  pkg=$1
  echo "Processing $pkg..." >> $log_file
  cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow
  cmd appops set $pkg RUN_IN_BACKGROUND allow
  dumpsys deviceidle whitelist +$pkg
  sleep 1
}

# Danh sách app
for pkg in \
  com.google.android.katniss \
  com.google.android.youtube.tv \
  com.spocky.projengmenu \
  com.liskovsoft.smarttubetv.beta \
  com.teamsmart.videomanager.tv \
  com.google.android.apps.tv.launcherx \
  com.google.android.tvlauncher \
  ai.zalo.kiki.tv; do
  disable_optimization $pkg
done

echo "=== Completed all packages ===" >> $log_file
date >> $log_file
