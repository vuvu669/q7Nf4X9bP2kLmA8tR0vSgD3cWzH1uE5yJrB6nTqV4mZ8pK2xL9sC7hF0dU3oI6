#!/system/bin/sh
# Magisk module: Performance Boost for TV Apps
# Author: Tony Vu
# Version: 1.0
#
# What it does:
# - When target apps run, attempt to set CPU governor to 'performance' (if supported)
# - Whitelist apps from deviceidle and allow background running via appops
# - Mark apps as active (cmd activity set-inactive false)
# - Keep minimal logging at /data/adb/modules/perf_boost_tvapps_v1/log.txt
#
MODDIR=${0%/*}
LOG=$MODDIR/log.txt
TARGET_APPS="com.google.android.youtube.tv com.google.android.katniss com.liskovsoft.smarttubetv.beta com.teamsmart.videomanager.tv ai.zalo.kiki.tv"
SLEEP_IDLE=5
echo "[perf_boost] start $(date)" > $LOG

# Wait for system boot complete
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 1
done
sleep 5

# helper: run and log
run() {
  echo "[`date +%H:%M:%S`] $*" >> $LOG
  $* >> $LOG 2>&1 || true
}

# Whitelist and appops (idempotent)
ensure_whitelist_and_appops() {
  for pkg in $TARGET_APPS; do
    run cmd appops set $pkg RUN_ANY_IN_BACKGROUND allow
    run cmd appops set $pkg RUN_IN_BACKGROUND allow
    run cmd appops set $pkg FOREGROUND_SERVICE_ALLOWED allow
    run dumpsys deviceidle whitelist +$pkg
    run cmd activity set-inactive $pkg false
  done
}

# Attempt to set CPU governor to performance; save originals
set_performance_governor() {
  for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
    gov_file="$cpu/cpufreq/scaling_governor"
    if [ -w "$gov_file" ]; then
      orig_file="$MODDIR/$(basename $cpu)_orig_gov"
      if [ ! -f "$orig_file" ]; then
        cat "$gov_file" > "$orig_file" 2>/dev/null || echo "unknown" > "$orig_file"
        run echo performance > "$gov_file"
      else
        run echo performance > "$gov_file"
      fi
    fi
  done
}

# Restore governors if we changed them
restore_governor_if_needed() {
  for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
    gov_file="$cpu/cpufreq/scaling_governor"
    orig_file="$MODDIR/$(basename $cpu)_orig_gov"
    if [ -w "$gov_file" ] && [ -f "$orig_file" ]; then
      orig=$(cat "$orig_file" 2>/dev/null)
      if [ -n "$orig" ]; then
        run echo "$orig" > "$gov_file"
        rm -f "$orig_file"
      fi
    fi
  done
}

# Check if any target app is running (by pidof)
any_target_running() {
  for pkg in $TARGET_APPS; do
    if pidof $pkg >/dev/null 2>&1; then
      return 0
    fi
  done
  return 1
}

# Main loop: monitor and apply
ensure_whitelist_and_appops
active_before=0
while true; do
  if any_target_running; then
    if [ "$active_before" -eq 0 ]; then
      run echo "Target app detected - applying performance settings" >> $LOG
      set_performance_governor
      ensure_whitelist_and_appops
      active_before=1
    fi
  else
    if [ "$active_before" -eq 1 ]; then
      run echo "No target app running - restoring governors" >> $LOG
      restore_governor_if_needed
      active_before=0
    fi
  fi
  sleep $SLEEP_IDLE
done &

echo "[perf_boost] service started." >> $LOG
