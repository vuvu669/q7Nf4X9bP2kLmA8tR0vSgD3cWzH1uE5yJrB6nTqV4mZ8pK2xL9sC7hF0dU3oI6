
Final Combined Magisk Module v3
- Privileged APKs in /system/priv-app/: Giaodien, ATVSKeyboard, FMP, HTCD
- User-space apps (auto-installed at boot) in module common/: Shizuku.apk, AppManager.apk (installed via pm install -r)
- .replace for TVLauncherXPrebuilt (systemless remove Google TV launcher)
- service.sh installs user apps from common/ and performs best-effort IME/launcher setup and removes unwanted packages
- NOTE: pm install from module common/ does not require /sdcard and runs from module path under /data/adb/modules
- Backup before flashing. Flash at your own risk.
