#!/system/bin/sh
# call service in background
/data/adb/modules/final_custom_module_v3/service.sh &
