#!/system/bin/sh
# service.sh - final_custom_module_v3 (no aapt version)
# Gỡ app trước, chỉ cài app nếu bị gỡ, không dùng aapt

SLEEP=15
sleep $SLEEP

# ---------- GỠ SYSTEMLESS GOOGLE TV LAUNCHER MỖI LẦN BOOT ----------
echo "🗑️ Xóa systemless Google TV Launcher mỗi lần boot..."

LAUNCHER_PATHS="
/system/priv-app/TvLauncherXPrebuilt
/system/priv-app/TvLauncher
/system/priv-app/GoogleTvLauncher
/system/priv-app/com.google.android.tvlauncher
/system/priv-app/com.google.android.apps.tv.launcherx
"

for path in $LAUNCHER_PATHS; do
  if [ -d "$path" ]; then
    echo "🧹 Xóa $path ..."
    rm -rf "$path" 2>/dev/null || true
    touch "$path/.replace" 2>/dev/null || true
  fi
done

MOD_MOUNT="/data/adb/modules_mount"
if [ -d "$MOD_MOUNT" ]; then
  find "$MOD_MOUNT" -type d -path "*/TvLauncher*" -exec rm -rf {} + 2>/dev/null
  find "$MOD_MOUNT" -type d -path "*/GoogleTvLauncher*" -exec rm -rf {} + 2>/dev/null
fi

echo "✅ Đã xử lý xong Google TV Launcher systemless."


MOD_DIR="/data/adb/modules/final_custom_module_v3"
COMMON_DIR="$MOD_DIR/common"

# Ensure system.prop has correct permissions
if [ -f "$MOD_DIR/system.prop" ]; then
  chmod 0644 "$MOD_DIR/system.prop" 2>/dev/null || true
fi

AUTOINSTALL_DIR="$COMMON_DIR/autoinstall"

APK_SHIZ="$COMMON_DIR/Shizuku.apk"
APK_AM="$COMMON_DIR/AppManager.apk"

# ---------- 1. GỠ APP KHÔNG MUỐN GIỮ LẠI ----------
FLAG_REMOVE="$MOD_DIR/.remove_done"

if [ ! -f "$FLAG_REMOVE" ]; then
  REMOVE_PKGS="com.netflix.mediaclient com.android.chrome org.xbmc.kodi com.google.android.youtube.tv com.droidlogic.mediacenter com.oranth.filebrowser com.android.gallery3d"
  for p in $REMOVE_PKGS; do
    echo "🗑️ Gỡ $p ..."
    pm uninstall --user 0 "$p" 2>/dev/null || true
    pm disable-user --user 0 "$p" 2>/dev/null || true
  done
  touch "$FLAG_REMOVE"
fi

# ---------- 1B. GỠ THÊM CÁC APP KHÔNG CẦN THIẾT (CHỈ CHẠY 1 LẦN) ----------
EXTRA_REMOVE_PKGS="com.droidlogic.appinstall com.oranth.bluetoothremote com.oranth.filebrowser com.droidlogic.FileBrower com.android.camera2 com.droidlogic.miracast"

FLAG_EXTRA_REMOVE="$MOD_DIR/.extra_remove_done"

if [ ! -f "$FLAG_EXTRA_REMOVE" ]; then
  for p in $EXTRA_REMOVE_PKGS; do
    echo "🧹 Gỡ thêm $p ..."
    pm uninstall --user 0 "$p" 2>/dev/null || true
    pm disable-user --user 0 "$p" 2>/dev/null || true
  done
  touch "$FLAG_EXTRA_REMOVE"
fi


# ---------- 2. FIX QUYỀN CHO PRIV-APP ----------
fix_perms() {
  f="$1"
  if [ -f "$f" ]; then
    chown 0:0 "$f" 2>/dev/null || true
    chmod 0644 "$f" 2>/dev/null || true
    dir=$(dirname "$f")
    chown 0:0 "$dir" 2>/dev/null || true
    chmod 0755 "$dir" 2>/dev/null || true
    if command -v restorecon >/dev/null 2>&1; then
      restorecon -R "$dir" 2>/dev/null || true
    fi
  fi
}

fix_perms "/system/priv-app/Giaodien/Giaodien.apk"
fix_perms "/system/priv-app/ATVSKeyboard/ATVSKeyboard.apk"
fix_perms "/system/priv-app/FMP/FMP.apk"
fix_perms "/system/priv-app/HTCD/HTCD.apk"

# ---------- 3. CÀI APP NẾU BỊ GỠ (KHÔNG DÙNG AAPT) ----------
if [ -d "$AUTOINSTALL_DIR" ]; then
  PKGLIST="$AUTOINSTALL_DIR/pkglist.txt"
  if [ -f "$PKGLIST" ]; then
    while IFS='=' read -r apk pkg; do
      [ -z "$apk" ] && continue
      [ -z "$pkg" ] && continue
      APK_PATH="$AUTOINSTALL_DIR/$apk"
      if [ -f "$APK_PATH" ]; then
        if pm list packages | grep -q "$pkg"; then
          echo "✅ $pkg đã tồn tại, bỏ qua."
        else
          echo "📦 Cài $pkg ..."
          pm install "$APK_PATH" >/dev/null 2>&1 && echo "→ Cài xong $pkg"
        fi
      fi
    done < "$PKGLIST"
  else
    echo "⚠️ Không thấy pkglist.txt trong autoinstall/"
  fi
fi

# ---------- 4. CÀI APP MANAGER CHỈ 1 LẦN ----------
FLAG_AM="$MOD_DIR/.am_installed"
PKG_AM="io.github.muntashirakon.AppManager"

if [ -f "$APK_AM" ]; then
  if [ ! -f "$FLAG_AM" ]; then
    pm install -r "$APK_AM" 2>/dev/null && touch "$FLAG_AM"
  else
    if pm list packages | grep -q "$PKG_AM"; then
      true
    else
      echo "⚠️ AppManager bị gỡ, bỏ qua cài lại."
    fi
  fi
fi





# ---------- 7. ĐẶT GIAO DIỆN LÀM LAUNCHER MẶC ĐỊNH ----------
PKG_GIAO=$(pm list packages -f | grep "Giaodien.apk" | sed -n 's/^.*=//p' | head -n1)
if [ -n "$PKG_GIAO" ]; then
  HOME_CANDS=$(cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME 2>/dev/null || true)
  default_comp=$(echo "$HOME_CANDS" | grep "$PKG_GIAO" | head -n1)
  if [ -n "$default_comp" ]; then
    cmd package set-home-activity "$default_comp" 2>/dev/null || true
  fi
fi

exit 0
